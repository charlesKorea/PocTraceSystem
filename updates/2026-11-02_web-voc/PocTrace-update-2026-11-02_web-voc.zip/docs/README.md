# PocTrace 문서 안내 / 文档说明

| 파일 / 文件 | 언어 | 용도 |
|-------------|------|------|
| `PocTrace_Validation_Catalog_KO.csv` | 한국어 | 검수 항목 → **Excel에서 바로 열기** |
| `PocTrace_Validation_Catalog_ZH.csv` | 中文 | 检核项目 → **用Excel直接打开** |
| `PocTrace_Validation_Catalog_KO.md` | 한국어 | 표 복사→Excel 붙여넣기용 |
| `PocTrace_Validation_Catalog_ZH.md` | 中文 | 表格复制→Excel |
| `PocTrace_Special_Trace_Rules_KO.md` / `.csv` | 한국어 | **Water/MainLine Takeoff 등 특수 Trace 로직** |
| `PocTrace_Special_Trace_Rules_ZH.md` / `.csv` | 中文 | **Water/MainLine Takeoff 等特殊 Trace 逻辑** |
| `PocTrace_User_Manual_KO.md` | 한국어 | 사용자 매뉴얼 |
| `PocTrace_User_Manual_ZH.md` | 中文 | 用户手册 |
| `PocTrace_Validation_and_Manual.xlsx` | 한·중 | 검수 + 특수규칙 시트 통합 |
| `SVDI-SHARED-RUN.md` | 한국어 | **SVDI 실행 기준**. Admin은 D:, UI·철거·노즐·Web은 같은 폴더와 같은 Core.dll. 코딩할 때 이 문서를 따른다 |
| `UPDATE-2026-10.md` | 한국어 | **2026-10 변경 요약** (캐시 로드 메모리, Web 포털, JLic 검증, 배포) |
| `SVDI_XDrive_Manual_Deploy_KO.md` | 한국어 | **SVDI X: 수동 배포·Admin 영향** |
| `WebPortal_API_Concept_KO.md` | 한국어 | **웹 포털 API 구상** (WinForms → HTML, Core 재사용, GET/POST) |
| `PocTrace.Web/README.md` | 한국어 | **PocTrace.Web 실행** (Viewer와 병행, X: 배포, UiAssets 파일 목록) |
| `UPDATE-2026-11-Web-VOC_KO.md` | 한국어 | **2026-11 Web VOC 11건 반영 내역**, 설정 키, 공용 검수 기록 구조 |
| `Web_Table_Layout_Guide_KO.md` | 한국어 | **Web 표가 머리글을 벗어나는 문제**의 원인과 표 작성 규칙 |
| `../updates/README.md` | 한국어 | **변경 파일만 받는 업데이트 zip** 목록과 만드는 방법 |
| `PocTrace.DeletedPipeLength/가이드.md` | 한국어 | **삭제 배관 길이 Excel** 열 뜻, 순서 열, 탐색 상한 |
| `BinaryCache_Easy_Guide_KO.md` | 한국어 | **공유 캐시 쉬운 설명**（비개발자·동료 공유） |
| `BinaryCache_Easy_Guide_ZH.md` | 中文 | **共享缓存简明说明**（非开发同事共享） |

CSV는 UTF-8 BOM이라 Excel에서 한글/중국어가 깨지지 않습니다.
